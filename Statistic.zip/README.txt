# First number indicates which construction method to use: 
1. Nearest Neighbour
2. Clarke Wright Savings
3. Minimum Spanning Tree
# Second number indicates whether to use Randomness in VND or not:
1. Use Randomized VND
2. Not use Randomized VND
# Third number indicates whether to use AFS reallocation as operator or not:
1. Use AFS reallocation
2. Not use AFS reallocation

For example: 3-1-2 is Minimum Spanning Tree + Use Randomized VND + Not use AFS reallocation
